require('dotenv').config();
const req=n=>{if(!process.env[n])throw new Error(`Missing ${n}`);return process.env[n]};
module.exports={
 token:req('BOT_TOKEN'),clientId:req('CLIENT_ID'),clientSecret:process.env.CLIENT_SECRET||'',publicKey:process.env.PUBLIC_KEY||'',ownerId:req('BOT_OWNER_ID'),
 redirectUri:process.env.OAUTH2_REDIRECT_URI||'http://localhost:3000/oauth/callback',scopes:(process.env.OAUTH2_SCOPES||'identify,guilds.join').split(',').map(x=>x.trim()).filter(Boolean),
 db:req('DATABASE_URL'),port:Number(process.env.WEB_PORT||3000),stateTtl:Number(process.env.OAUTH_STATE_TTL_SECONDS||600),sessionSecret:req('SESSION_SECRET'),
 payoutCentralId:process.env.PAYOUT_CENTRAL_SERVER_ID||'',verifiedRoleId:process.env.VERIFIED_ROLE_ID||'',specialChannelId:process.env.SPECIAL_CHANNEL_ID||'',
 defaultPrefix:process.env.DEFAULT_PREFIX||'!',baseSend:Number(process.env.DEFAULT_BASE_SEND||2),queueCapacity:Number(process.env.DEFAULT_QUEUE_CAPACITY||10),cooldown:Number(process.env.DEFAULT_COOLDOWN_SECONDS||0)
};
